# Writing a program that removes null values form the data-set
from Overview import df

# Dealing with null values in marital status:
# =============================================================================
# print(df['marital_status'].value_counts())
# =============================================================================
# Since 'married' is the mode, we replace the null values of marital status with 'married'
df['marital_status'] = df['marital_status'].fillna(df['marital_status'].mode()[0])


# Dealing with null values in education
# =============================================================================
# print(df['education'].value_counts())
# =============================================================================
# Since we have a category called 'unknown' we will use it to fill the null values
df['education'] = df['education'].fillna('unknown')
# =============================================================================
# print(df['education'].value_counts())
# =============================================================================


# Removing duplicate columns
# Checking for marital status and marital
# =============================================================================
# print(df['marital'].value_counts())
# print(df['marital_status'].value_counts())
# =============================================================================
# Both are exactly same. So, I drop the category iof marital
df.drop(columns=['marital'],inplace = True)
# =============================================================================
# print(df.columns)
# =============================================================================
