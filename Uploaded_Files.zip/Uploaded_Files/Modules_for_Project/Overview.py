# Writing a program which returns the overview of a data set
import pandas as pd

# Fetching the banking_data file:
df = pd.read_csv(r"C:\Users\Dell\Desktop\ABHYAS\FINANCE\Notes for Finlatics's Data Science Program_From Capsule 2_Exception Handling\Project\DsResearch\DsResearch\Banking\banking_data.csv")

#Changing the default display limit to None
pd.set_option('display.max_rows',None)  # Ensures that all rows are displayed without truncation
pd.set_option('display.max_columns',None)   #Ensures that all columns are displayed without truncation

#Getting an overview of the data set
class data_overview:
   
# Displaying a brief info about the data set
    
    def display_info(self,Data = df):
        print("\nThis is an overview of the data set:")
        print('____________________________________________________________________________________________')
        print("An info about the given dataset:\n",Data.info())
    
    # Displaying the names of all the columns present in the data set
    def display_column_name(self,Data = df):
        print('____________________________________________________________________________________________')
        print("\nThe columns present in the data are:",Data.columns)
    
    # Displaying the size of the data
    def display_data_size(self,Data = df):
        print('____________________________________________________________________________________________')
        print("\nThe size of the data (rows,columns) is:",Data.shape)
        
    # Displaying the number of unique counts for each title in all columns
    def display_number_of_unique_count(self,Data = df):
        print('____________________________________________________________________________________________')
        print("\nThe number of unique counts for each title in all columns for the given data set are displayed as:\b")
        print(Data.nunique())
        
    #Displaying the unique_counts for each title in all columns
    def display_all_unique_count(self,Data = df):
        print('____________________________________________________________________________________________')
        print("\nThe unique counts for each title in all columns for the given data set are:\n")
        for column_title in Data.columns:
            print(column_title,' \n\n',Data[column_title].unique())
            print('\n')
            
    # Displaying a description of the data set
    def display_a_description_of_data_set(self,Data = df):
        print('____________________________________________________________________________________________')
        print("\nA description of the complete data is as follows:\n\n",Data.describe())
        
    #Displaying a description of each topic in all columns
    def display_complete_description(self,Data = df):
        print('____________________________________________________________________________________________')
        print("The description of each title in all columns:\n")
        for column_title in Data.columns:
            print(column_title,'\n\n',Data[column_title].describe())
            print('\n')
    
    # Displaying the null values in each column
    def display_null_values(self,Data = df):
        print('____________________________________________________________________________________________')
        print("The null values present in the data are as follows:\n")
        print(Data.isnull().sum())
        print('____________________________________________________________________________________________')


        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        