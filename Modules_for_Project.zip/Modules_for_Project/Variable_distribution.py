import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from null_values_dealt import df

def show_distribution(numeric):
    
    if numeric == 'age':a,b,c,r,u = 10,110,10,0,0.013
    if numeric == 'balance1':numeric,a,b,c,r,u = 'balance',-8200,0,1000,60,0.002
    if numeric == 'balance2':numeric,a,b,c,r,u = 'balance',0,140000,20000,60,0.013
    if numeric == 'balance3':numeric,a,b,c,r,u = 'balance',0,40000,4000,60,0.024
    if numeric == 'duration1':numeric,a,b,c,r,u = 'duration',0,6000,1000,60,0.048
    if numeric == 'duration2':numeric,a,b,c,r,u = 'duration',0,1100,200,60,0.048
    if numeric == 'campaign1':numeric,a,b,c,r,u = 'campaign',0,80,10,60,0.048
    if numeric == 'campaign2':numeric,a,b,c,r,u = 'campaign',0,35,5,60,0.06
    if numeric == 'pdays1':numeric,a,b,c,r,u = 'pdays',-10,0,1,0,0.048
    if numeric == 'pdays2':numeric,a,b,c,r,u = 'pdays',-4,2,1,0,0.048
    if numeric == 'pdays3':numeric,a,b,c,r,u = 'pdays',0,1000,100,60,0.01
    if numeric == 'previous1':numeric,a,b,c,r,u = 'previous',0,350,50,60,0.048
    if numeric == 'previous2':numeric,a,b,c,r,u = 'previous',0,30,5,60,0.048
    if numeric == 'previous3':numeric,a,b,c,r,u = 'previous',0,10,1,60,0.048
    if numeric == 'previous4':numeric,a,b,c,r,u = 'previous',0,5,1,60,0.048
    if numeric == 'day':numeric,a,b,c,r,u = 'day',0,33,4,60,0.048
    if numeric == 'month':numeric,a,b,c,r,u = 'month',0,13,1,60,0.084
    if numeric == 'job':numeric,a,b,c,r,u = 'job',0,13,1,60,0.048
    if numeric == 'marital_status':numeric,a,b,c,r,u = 'marital_status',0,4,1,0,0.060
    if numeric == 'education':numeric,a,b,c,r,u = 'education',0,5,1,0,0.048
    if numeric == 'default':numeric,a,b,c,r,u = 'default',0,3,1,0,0.048
    if numeric == 'housing':numeric,a,b,c,r,u = 'housing',0,3,1,0,0.048
    if numeric == 'loan':numeric,a,b,c,r,u = 'loan',0,3,1,0,0.030
    if numeric == 'contact':numeric,a,b,c,r,u = 'contact',0,4,1,0,0.048
    if numeric == 'poutcome':numeric,a,b,c,r,u = 'poutcome',0,5,1,0,0.053
    if numeric == 'y':numeric,a,b,c,r,u = 'y',0,3,1,0,0.06


    
    data = df[numeric]
    bins = range(a,b,c)
    # Plot the histogram
    counts_contacted, bins_contacted, patches_contacted = plt.hist(data, bins=bins, color='skyblue', label='People who were contacted.',weights=[1/len(data)]*len(data), edgecolor='black')
    
    # Set the y-axis to percentage
    plt.gca().yaxis.set_major_formatter(PercentFormatter(xmax=1, symbol='%'))
    
    # Annotate bars with percentages
    for count, bin_edge in zip(counts_contacted, bins_contacted[:-1]):
        percentage = count * 100
        plt.text(bin_edge + (bins[1] - bins[0]) / 2, count / 2 + u, f'{percentage:.2f}%', ha='center', va='bottom')
    
    
    # Set titles and labels
    plt.title(f'Distribution corresponding to {numeric.title()}')
    plt.xlabel(numeric)
    plt.ylabel('Percentage')
    plt.xticks(rotation = r)
    # Show the plot
    plt.show()
