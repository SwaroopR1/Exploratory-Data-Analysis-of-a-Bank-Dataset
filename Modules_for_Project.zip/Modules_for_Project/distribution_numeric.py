# Writing a program which returns the distribution of the data set:
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from Overview import df
import numpy as np



# Getting the distribution corresponding to a particular category from the clients
class numeric_distribution:
    
    # Getting the unique values present in the 'numeric' column
    def display_unique_count(self,numeric):
        if numeric != 'duration':
            print(f"\nThis is a description of the distribution corresponding to {numeric}:")
        elif numeric == 'duration':
            print(f"\nThis is a description of the distribution of the {numeric} (in seconds) of the last contact with the clients:")
        print('____________________________________________________________________________________________')
        if numeric != 'duration':
            print(f"\nThe unique values corresponding to {numeric}:\n",df[numeric].unique())
        elif numeric == 'duration':
            print(f"\nThe unique values present in the {numeric} of the last contact with the clients are:\n",df[numeric].unique())
        # print('____________________________________________________________________________________________')
    
    # Getting the total number of entries
    def total_entries(self,numeric):
        print('____________________________________________________________________________________________')
        if numeric != 'duration':
            print(f"The total number of unique entries corresponding to {numeric}:\n",len(df[numeric].unique()))
        elif numeric =='duration':
            print(f"The total number of unique entries for the {numeric} of the last contact with the clients is:\n",len(df[numeric].unique()))
        # print('____________________________________________________________________________________________')
    
    # Getting the value_count for all the uniques values
    def display_value_count(self,numeric):
        print('____________________________________________________________________________________________')
        if numeric != 'duration':
            print(f"\nThe count of all the unique values corresponding to {numeric}:\n",df[numeric].value_counts())
        elif numeric == 'duration':
            print(f"\nThe count of all the unique values for the {numeric} of the last contact with the clients are as follows:\n",df[numeric].value_counts())
        print('____________________________________________________________________________________________')
    
    # Printing a description of the numeric column
    def display_description(self,numeric):
        # print('____________________________________________________________________________________________')
        if numeric != 'duration':
            print(f"\nA description corresponding to {numeric}::\n\b",df[numeric].describe())
        elif numeric == 'duration':
            print(f"\nA description of the {numeric} of the last contact with the clients is as follows:\n\b",df[numeric].describe())
        # print('____________________________________________________________________________________________')
    
    # Printing the number of missing values
    def display_missing_values(self,numeric):
        print('____________________________________________________________________________________________')
        if numeric != 'duration':
            print(f"\nThe number of missing values corresponding to {numeric}:",df[numeric].isnull().sum())
        elif numeric == 'duration':
            print(f"\nThe number of missing values for the {numeric} of the last contact with the clients {numeric} is",df[numeric].isnull().sum())
        print('____________________________________________________________________________________________')
    
    #Printing a box plot
    def display_box_plot(self,numeric):
        sns.boxplot(y=numeric,data = df)
        plt.title(f"Box plot corresponding to {numeric}")
        plt.show()

    
# Defining a class for analysis of outliers
class outlier_find():
    
    
    # A function that finds the outliers
    def outliers(self,numeric):
        # Calculate Q1 (25th percentile) and Q3 (75th percentile)
        Q1 = df[numeric].quantile(0.25)
        Q3 = df[numeric].quantile(0.75)
        IQR = Q3 - Q1
        # Define the lower and upper bound to identify outliers
        lower_bound = Q1 - 1.5*IQR
        upper_bound = Q3 + 1.5*IQR
        # Identifying outliers:
        self.outlier_rows = df[(df[numeric]<lower_bound)|(df[numeric]>upper_bound)]
        self.non_outlier_rows = df[(df[numeric]>=lower_bound)&(df[numeric]<=upper_bound)]

    # A function describing the outliers and non-outliers present
    def description_of_outliers_nonoutliers(self,numeric):
        # print('____________________________________________________________________________________________')
        if numeric != 'duration':
            print(f"\nA description of the outliers corresponding to {numeric}:\n")
        elif numeric == 'duration':
            print(f"\nA description of the outliers present in the {numeric} of the last contact with the clients:\n")
        print(self.outlier_rows.describe())
        print('____________________________________________________________________________________________')
        if numeric != 'duration':
            print(f"\nA description of the non-outliers corresponding to {numeric}:\n")
        elif numeric == 'duration':
            print(f"\nA description of the non-outliers present in the {numeric} of the last contact with the clients:\n")
        print(self.non_outlier_rows.describe()) 

    # A function that displays a box plot for the outliers present in the data set    
    def box_plot_outlier_rows(self,numeric):
        sns.boxplot(y=numeric,data = self.outlier_rows)
        if numeric != 'duration':
            plt.title(f"Box plot for the outliers corresponding to {numeric}")
        elif numeric == 'duration':
            plt.title(f"Box plot for the outliers in the {numeric} of the last contact with the clients")
        plt.show()
    
    # A function that displays a box plot for the non-outliers present in the data set    
    def box_plot_non_outlier_rows(self,numeric):
        sns.boxplot(y=numeric,data = self.non_outlier_rows)
        if numeric !='duration':
            plt.title(f"Box plot for the non-outliers corresponding to {numeric}")
        elif numeric == 'duration':
            plt.title(f"Box plot for the non-outliers in the {numeric} of the last contact with the clients")
        plt.show()
        
class non_outlier(outlier_find):
        
    #the 'outliers' method must be called first to initialize self.non_outlier_rows before it can be accessed by the non_outlier class.       
    def __init__(self,numeric):
        self.outliers(numeric)
        
        # Creating a countplot for 'numeric's non-outlier data' vs number of people
    def display_countplot(self,numeric):
        sns.countplot(x=numeric, hue='y', data=self.non_outlier_rows)
        plt.xlabel(numeric)
        plt.ylabel("Number of People")
        plt.title(f"{numeric.title()} vs Subscription for Non-Outlier Data")

        if numeric == 'age':
            plt.xticks(range(-10,100,10))
            plt.grid(True)
            plt.xlim(-10,60)

        plt.legend(title = 'Subscription status')
        plt.show()
        
    # Creating a catplot for 'age' vs number of people in the category of jobs
    def display_catplot(self,numeric):
        g = sns.catplot(x=numeric,hue='y',col='job',data = self.non_outlier_rows,kind = 'count',palette='Set2')
        g._legend.remove()
        plt.xlabel(numeric)

        for ax in g.axes.flat:
            ax.set_ylabel('Number of people')
        plt.suptitle(f'Number of people and their {numeric} in various jobs, for non-outlier data',y = 1.06)
        if numeric =='age':
            plt.xticks(range(-10,70,10))
            plt.xlim(-10,70)
        plt.legend(title = 'Subscription status')
        plt.show()

    # Creating a function that removes the "no" values from the non_outlier_rows data
    def remove_no(self,numeric):

        if numeric == 'age':a,b,c,r,u = 0,90,10,0,0.66
        elif numeric == 'balance': a,b,c,r,u = -2000,4000,400,45,1.2
        elif numeric == 'duration':a,b,c,r,u = 0,700,50,45,1.0
        elif numeric == 'campaign': a,b,c,r,u = 0,7,1,0,0.66
        elif numeric == 'pdays':a,b,c,r,u = -2,2,1,0,0.66
        elif numeric == 'previous':a,b,c,r,u = -2,2,1,0,0.66
       
        # Define the bins
        bins = range(a,b,c)
        
        # Plotting the histogram for people who were contacted
        counts_contacted, bins_contacted, patches_contacted = plt.hist(self.non_outlier_rows[numeric], bins=bins, color='skyblue', edgecolor='black', label='People who were contacted.')
        
        
        self.non_outlier_rows['y'].replace({'no':pd.NA},inplace = True)  # replaces occurrences of 'no' with pd.NA, which represents a missing value in pandas.
        self.non_outlier_rows.dropna(subset=['y'],inplace = True)
        counts_subscribed, bins_subscribed, patches_subscribed = plt.hist(self.non_outlier_rows[numeric], bins=bins, color='pink', edgecolor='black', label='People who took subscription.')
        
        
        # Annotate the bars with percentages
        for i in range(len(bins_contacted) - 1):
            total_in_bin = counts_contacted[i]
            if total_in_bin > 0:
                # Calculate percentage for people in the bin who took subscription 
                percentage_subscribed = (counts_subscribed[i] / total_in_bin) * 100
                percentage_contacted = 100 - percentage_subscribed  # Remaining percentage for contacted but not subscribed

                # Annotate the subscribed bar
                plt.text(bins_subscribed[i] + (bins_subscribed[i + 1] - bins_subscribed[i]) / 2,
                         counts_subscribed[i] + (total_in_bin * u),  # Position text slightly above the top of the bar
                         f'  {percentage_subscribed:.1f}%',
                         ha='center',
                         va='bottom',
                         color='black',
                         fontsize=8)
        if numeric == 'balance':
            plt.plot(0,4000,0,30000)
        elif numeric == 'duration':
            plt.plot(0.700,0,9000)
        plt.xticks(bins,fontsize = 8.5)   
        plt.xticks(rotation = r)
        plt.xlabel(numeric)
        plt.ylabel('Number of people who were contacted')
        if numeric != 'duration':
            plt.title(f'Histogram for non-outlier values corresponding to {numeric}')
        elif numeric == 'duration':
            plt.title(f'Histogram for non-outlier values for the {numeric} of the last contact with the clients')
        plt.legend()
        plt.tight_layout()
        plt.show()


class outlier(outlier_find):
    
    #the 'outliers' method must be called first to initialize self.outlier_rows before it can be accessed by the outlier class.       
    def __init__(self,numeric):
        self.outliers(numeric)
    
    # Creating a countplot for "numeric's outlier data" vs number of people
    def display_countplot1(self,numeric):
        sns.countplot(x=numeric, hue='y', data=self.outlier_rows)
        plt.xlabel(numeric)
        plt.ylabel("Number of People")
        plt.title(f"{numeric.title()} vs Subscription for Outlier Data")
        if numeric == 'age':
            plt.xticks(range(-10,30,5))
            plt.grid(True)
            plt.xlim(-10,30)
        plt.legend(title = 'Subscription status')
        plt.show()
        
        # Creating a catplot for age vs number of people in the category of jobs
    def display_catplot1(self,numeric):
        g = sns.catplot(x=numeric,hue='y',col='job',data = self.outlier_rows,kind = 'count',palette='Set2')
        g._legend.remove()
        plt.xlabel(numeric)
        for ax in g.axes.flat:
            ax.set_ylabel('Number of people')

        plt.suptitle(f'Number of people and their {numeric} in various jobs, for outlier data', y = 1.06)
        if numeric =='age':
            plt.xticks(range(-10,30,5))
            plt.xlim(-10,30)
        plt.legend(title = 'Subscription status')
        plt.show()

    # Creating a function that removes the "no" values from the outlier_rows data
    def remove_no1(self,numeric):
        if numeric =='age': a,b,c,r,u = 60,120,10,0,0.006
        elif numeric == 'balance': a,b,c,r,u = -8500,105000,10000,45,0.9
        elif numeric == 'duration':a,b,c,r,u = 600,5500,500,45,0.66
        elif numeric == 'campaign':a,b,c,r,u = 6,70,5,0,1.0
        elif numeric == 'pdays':a,b,c,r,u = 0,900,80,45,1.0
        elif numeric == 'previous':a,b,c,r,u = 0,300,30,45,0.66
    # Define the bins
        bins = range(a,b,c)  
        
        # Plot the histogram for people who were contacted
        counts_contacted, bins_contacted, patches_contacted = plt.hist(self.outlier_rows[numeric], bins=bins, color='skyblue', edgecolor='black', label='People who were contacted.')
        self.outlier_rows['y'].replace({'no':pd.NA},inplace = True)  # replaces occurrences of 'no' with pd.NA, which represents a missing value in pandas.
        self.outlier_rows.dropna(subset=['y'],inplace = True)
        counts_subscribed, bins_subscribed, patches_subscribed = plt.hist(self.outlier_rows[numeric], bins=bins, color='pink', edgecolor='black', label='People who took subscription.')
        
        # Annotate the bars with percentages
        for i in range(len(bins_contacted) - 1):
            total_in_bin = counts_contacted[i]
            if total_in_bin > 0:
                # Calculate percentage for people in the bin who took subscription
                percentage_subscribed = (counts_subscribed[i] / total_in_bin) * 100
                percentage_contacted = 100 - percentage_subscribed  # Remaining percentage for contacted but not subscribed

                # Annotate the subscribed bar
                plt.text(bins_subscribed[i] + (bins_subscribed[i + 1] - bins_subscribed[i]) / 2,
                         counts_subscribed[i] + (total_in_bin * u),  # Position text slightly above the top of the bar
                         f'{percentage_subscribed:.1f}%',
                         ha='center',
                         va='bottom',
                         color='black',
                         fontsize=8)
        
        if numeric == 'duration':
            plt.plot(0,3000,0,3500)
        elif numeric == 'balance':
            plt.plot(0,5000,0,6000)
        elif numeric == 'campaign':
            plt.plot(0,70,0,2500)
        elif numeric == 'pdays':
            plt.plot(0,900,0,3000)
        plt.xticks(bins,rotation = r)    
        plt.xlabel(numeric)
        plt.ylabel('Number of people who were contacted')
        if numeric != 'duration':
            plt.title(f'Histogram for outlier values corresponding to {numeric}')
        elif numeric == 'duration':
            plt.title(f'Histogram for outlier values for the {numeric} of the last contact with the clients')

        plt.legend()
        plt.show()
    


# We shall use the below class when the outliers are significantly important, and so we decide to analyze the complete data set.
class complete_data_analysis():
    def display_countplot2(self,numeric):
        sns.countplot(x=numeric, hue='y', data=df)

        plt.xlabel(numeric)
        plt.ylabel("Number of People")
        plt.title(f"{numeric.title()} vs Subscriptions")

        if numeric == 'day': a,b,c,r,f = -10,40,10,0,12
        if numeric == 'month':a,b,c,r,f = -1,13,1,0,12
        if numeric == 'job': a,b,c,r,f = -1,13,1,60,8
        if numeric == 'marital_status':a,b,c,r,f = -1,4,1,0,12
        if numeric == 'education':a,b,c,r,f = -1,4,1,0,12
        if numeric == 'default':a,b,c,r,f = -1,3,1,0,12
        if numeric == 'housing':a,b,c,r,f = -1,3,1,0,12
        if numeric == 'loan':a,b,c,r,f = -1,3,1,0,12
        if numeric == 'contact':a,b,c,r,f = -1,4,1,0,12
        if numeric == 'poutcome':a,b,c,r,f = -1,5,1,0,12
        if numeric == 'y': a,b,c,r,f = -1,3,1,0,12
        plt.xticks(range(a,b,c),rotation = r,fontsize = f)
        plt.grid(True)
        plt.xlim(a,b)   
        plt.legend(title = 'Subscription status')
        plt.show()
        
        # Creating a catplot for 'numeric1 and numeric2' vs number of people
    def display_catplot2(self,numeric1,numeric2):
        g = sns.catplot(x=numeric1,hue='y',col=numeric2,data = df,kind = 'count',palette='Set2')
        g._legend.remove()
        plt.xlabel(numeric1)
        plt.ylabel("Number of people")
        plt.suptitle(f'Number of people and their coressponding {numeric1} and {numeric2}',y = 1.06)
        if numeric1 == 'day': a,b,c = -5,40,5
        plt.xticks(range(a,b,c))
        plt.xlim(a,b)
        plt.legend(title = 'Subscription status')
        plt.show()
    
        # Creating a histogram
    def histogram(self,numeric):
        if numeric == 'age': a,b,c,r,u = 0,110,10,0,0.66
        elif numeric == 'balance1':
            numeric = 'balance'
            a,b,c,r,u = -10000,50000,5000,45,0.9
        elif numeric == 'balance2':
            numeric = 'balance'
            a,b,c,r,u = 0,5000,400,45,1.2
        elif numeric == 'duration':a,b,c,r,u = 0,5000,500,45,0.66
        elif numeric == 'campaign': a,b,c,r,u = 0,70,5,0,1.0
        elif numeric == 1:
            numeric = 'pdays'
            a,b,c,r,u = -10,900,100,0,0.8
        elif numeric == 2:
            numeric = 'pdays'
            a,b,c,r,u = -5,0,1,0,0.66
        elif numeric == 3:
            numeric = 'pdays'
            a,b,c,r,u = 0,400,40,45,0.01
        elif numeric == 'previous':a,b,c,r,u = 0,300,50,45,0.66
        elif numeric == 'previous1':
            numeric = 'previous'
            a,b,c,r,u = 0,10,1,0,0.8
        elif numeric == 'previous2':
            numeric = 'previous'
            a,b,c,r,u = 0,20,2,0,0.8
        elif numeric =='day': a,b,c,r,u = 0,35,5,0,0.66
        
        elif numeric == 'month':a,b,c,r,u = -1,13,1,45,1.0
        
        elif numeric == 'job': a,b,c,r,u = -1,13,1,60,1.0
        elif numeric == 'marital_status': a,b,c,r,u = -1,5,1,0,0.5
        elif numeric == 'education':a,b,c,r,u = -1,6,1,0,0.5
        elif numeric == 'default':a,b,c,r,u = -1,3,1,0,0.5
        elif numeric == 'housing':a,b,c,r,u = -1,3,1,0,0.5
        elif numeric == 'loan':a,b,c,r,u = -1,3,1,0,0.5
        elif numeric == 'contact':a,b,c,r,u = -1,4,1,0,0.4
        elif numeric == 'poutcome':a,b,c,r,u = -1,5,1,0,1.0
        elif numeric == 'y': a,b,c,r,u = -1,3,1,0,0.66
        
        
        self.duplicate = df.copy()
        
        # Define the bins
       
        bins = range(a,b,c)
        
        # Plot the histogram for people who were contacted
        counts_contacted, bins_contacted, patches_contacted = plt.hist(self.duplicate[numeric], bins=bins, color='skyblue', edgecolor='black', label='People who were contacted.')
        
        # Removing all the nos for subscription from the 'balance' column
        self.duplicate['y'].replace({'no':pd.NA},inplace=True)# replaces occurrences of 'no' with pd.NA, which represents a missing value in pandas.
        self.duplicate.dropna(subset=['y'],inplace = True)
        
        # Plot the histogram for people who took subscription
        counts_subscribed, bins_subscribed, patches_subscribed = plt.hist(self.duplicate[numeric], bins=bins, color='pink', edgecolor='black', label='People who took subscription.')

        # Annotate the bars with percentages
        for i in range(len(bins_contacted) - 1):
            total_in_bin = counts_contacted[i]
            if total_in_bin > 0:
                # Calculate percentage for people in the bin who took subscription
                percentage_subscribed = (counts_subscribed[i] / total_in_bin) * 100
                percentage_contacted = 100 - percentage_subscribed  # Remaining percentage for contacted but not subscribed
                
                # Annotate the subscribed bar
                plt.text(bins_subscribed[i] + (bins_subscribed[i + 1] - bins_subscribed[i]) / 2,
                         counts_subscribed[i] + (total_in_bin * u),  # Position text slightly above the top of the bar
                         f'{percentage_subscribed:.1f}%',
                         ha='center',
                         va='bottom',
                         color='black',
                         fontsize=8)
        
        if numeric == 'balance':
            plt.plot(0,100,0,50000)
        elif numeric == 'campaign':
            plt.plot(0,70,0,60000)
        if a == 0:
            plt.plot(0,400,0,2000)
        if numeric == 'month':
            plt.plot(0,13,0,16000)
        if numeric == 'job':
            plt.plot(0,13,0,15000)
        if numeric == 'poutcome':
            plt.plot(0,6,0,45000)

            
        plt.xlabel(numeric)
        plt.ylabel('Number of people')
        if numeric != 'duration':
            plt.title(f'Histogram corresponding to {numeric} and subscription')
        elif numeric == 'duration':
            plt.title(f'Histogram for the {numeric} of the last contact with the clients and subscription')
        plt.xticks(bins,fontsize = 8.5)   
        plt.xticks(rotation = r)
        plt.legend()
        plt.show()

    def numeric_distribution_group(self,numeric1,numeric2):
        print(f"A description of {numeric1} and {numeric2} is:\n\t",df.groupby([numeric1,numeric2])[numeric1].count())
        