from Overview import data_overview
from null_values_dealt import df
from distribution_numeric import numeric_distribution
from distribution_numeric import outlier_find,outlier, non_outlier,complete_data_analysis
from Variable_distribution import show_distribution
import matplotlib.pyplot as plt

import seaborn as sns

print("\nEnter 1 if you want an overview of the complete data set.")
print("Enter the name of the following columns if you want to analyze their data:\n\n.",df.columns)
print("\nEnter 'correlation_matrix' for displaying a correlation matrix.")
answer =input('\n\t')


# Displaying overall description
if answer == '1':
    overview = data_overview()
    overview.display_info()
    overview.display_column_name()
    overview.display_data_size()
    overview.display_number_of_unique_count()
    overview.display_all_unique_count()
    overview.display_a_description_of_data_set()    
    overview.display_complete_description()
    overview.display_null_values()

# Displaying description for a particular category
elif answer =='age':
        
    show_distribution(answer)    
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)

    numeric = outlier_find()
    numeric.outliers(answer)
    numeric.description_of_outliers_nonoutliers(answer)
    numeric.box_plot_outlier_rows(answer)
    numeric.box_plot_non_outlier_rows(answer)
    
    numeric = complete_data_analysis()
    numeric.histogram(answer)
    
    numeric = non_outlier(answer)
    numeric.display_countplot(answer)
    numeric.display_catplot(answer)
    numeric.remove_no(answer)
    
    numeric = outlier(answer)
    numeric.display_countplot1(answer)
    numeric.display_catplot1(answer)
    numeric.remove_no1(answer)
    
    
elif answer =='balance':
    show_distribution(numeric = answer+'1')
    show_distribution(numeric = answer+'2')
    show_distribution(numeric = answer + '3')
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    print("Because of too many unique values for balance, we have decided to not show them here.")
    numeric.display_description(answer)
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = outlier_find()
    numeric.outliers(answer)
    numeric.description_of_outliers_nonoutliers(answer)
    numeric.box_plot_outlier_rows(answer)
    numeric.box_plot_non_outlier_rows(answer)    
    print("Since there are too many outliers, we are only considering the histogram of 'balance' for analysis.")
    
    numeric = non_outlier(answer)
    numeric.remove_no(answer)
    
    numeric = outlier(answer)
    numeric.remove_no1(answer)
    
    numeric = complete_data_analysis()
    numeric.histogram(answer+'1')
    numeric.histogram(answer+'2')

    
elif answer=='duration':
    show_distribution(answer+'1')
    show_distribution(answer+'2')   
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    print(f"Because of too many unique values for {answer}, we have decided to not show them here.")
    numeric.display_description(answer)
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = outlier_find()
    numeric.outliers(answer)
    numeric.description_of_outliers_nonoutliers(answer)
    numeric.box_plot_outlier_rows(answer)
    numeric.box_plot_non_outlier_rows(answer)
    
    numeric = non_outlier(answer)
    numeric.remove_no(answer)
    
    numeric = outlier(answer)
    numeric.remove_no1(answer)
    
    numeric = complete_data_analysis()
    numeric.histogram(answer)
    
elif answer == 'campaign':
    show_distribution(answer+'1')
    show_distribution(answer+'2')
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = outlier_find()
    numeric.outliers(answer)
    numeric.description_of_outliers_nonoutliers(answer)
    numeric.box_plot_outlier_rows(answer)
    numeric.box_plot_non_outlier_rows(answer)
    
    numeric = non_outlier(answer)
    numeric.remove_no(answer)
    
    numeric = outlier(answer)   
    numeric.remove_no1(answer)
    
    numeric = complete_data_analysis()
    numeric.histogram(answer)
    
elif answer == 'pdays':
    show_distribution(answer+'1')
    show_distribution(answer+'2')
    show_distribution(answer+'3')
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    print(f"Because of too many unique values for {answer}, we have decided to not show them here.")
    # numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)

    numeric = outlier_find()
    numeric.outliers(answer)    
    numeric.description_of_outliers_nonoutliers(answer)
    numeric.box_plot_outlier_rows(answer)
    numeric.box_plot_non_outlier_rows(answer)
    
    numeric = non_outlier(answer)
    numeric.remove_no(answer)
    
    numeric = outlier(answer)
    numeric.remove_no1(answer)
    
    numeric = complete_data_analysis()
    numeric.histogram(1)
    numeric.histogram(2)
    numeric.histogram(3)

        
elif answer =='previous':
    show_distribution(answer+'1')
    show_distribution(answer+'2')
    show_distribution(answer+'3')
    show_distribution(answer+'4')
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = outlier_find()
    numeric.outliers(answer)
    numeric.description_of_outliers_nonoutliers(answer)
    numeric.box_plot_outlier_rows(answer)
    numeric.box_plot_non_outlier_rows(answer)   
    
    numeric = non_outlier(answer)
    numeric.remove_no(answer)
    
    numeric = outlier(answer)
    numeric.remove_no1(answer)
    
    numeric = complete_data_analysis()
    numeric.histogram(answer)
    numeric.histogram(answer+'1')
    numeric.histogram(answer+'2')

    
elif answer=='day and month':
    numeric = complete_data_analysis()
    # numeric = numeric_distribution_group()
    numeric.numeric_distribution_group('day', 'month')
    numeric.display_catplot2('day', 'month')

elif answer == 'day':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.display_catplot2('day', 'month')
    numeric.histogram(answer)

elif answer == 'month':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.display_catplot2('day', 'month')
    numeric.histogram(answer)
    
elif answer == 'job':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)

elif answer == 'marital_status':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)

elif answer == 'education':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)
    
elif answer == 'default':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)
    
elif answer == 'housing':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)
    
elif answer == 'loan':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)

elif answer == 'contact':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)

elif answer == 'poutcome':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)

elif answer == 'y':
    show_distribution(answer)
    numeric = numeric_distribution()
    numeric.display_unique_count(answer)
    numeric.total_entries(answer)
    numeric.display_value_count(answer)
    numeric.display_description(answer)   
    numeric.display_missing_values(answer)
    numeric.display_box_plot(answer)
    
    numeric = complete_data_analysis()
    numeric.display_countplot2(answer)
    numeric.histogram(answer)
   

elif answer =='correlation_matrix':    
    # Creating a correlation matrix
    numeric_df = df.select_dtypes(include=['int64','float64'])
    corr_matrix = numeric_df.corr()
    plt.figure(figsize=(10,8))
    sns.heatmap(corr_matrix,annot=True,cmap='PuBuGn',fmt =".2f")
    plt.title('Correlation Matrix of Given Dataset')
    plt.show()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    